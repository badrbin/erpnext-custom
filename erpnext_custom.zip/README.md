# erpnext_custom

Custom ERPNext app for payment entries.