
app_name = "erpnext_custom"
app_title = "ERPNext Custom"
app_publisher = "Your Name"
app_description = "Custom scripts for ERPNext"
app_email = "email@example.com"
app_license = "MIT"

doctype_js = {
    "Sales Order": "public/js/sales_order.js"
}
