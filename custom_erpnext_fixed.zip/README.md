# custom_erpnext

Custom ERPNext app for managing payment entries inside Sales Order.
