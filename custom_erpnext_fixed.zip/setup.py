
from setuptools import setup, find_packages

setup(
    name='custom_erpnext',
    version='0.0.1',
    description='Custom scripts for ERPNext',
    author='Your Name',
    author_email='email@example.com',
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=[],
)
