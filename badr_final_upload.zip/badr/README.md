# Badr

Custom Frappe app ready for deployment on Frappe Cloud.