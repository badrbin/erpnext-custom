
from . import __version__ as app_version

app_name = "badr"
app_title = "Badr"
app_publisher = "Your Name or Company"
app_description = "Badr is an empty Frappe app."
app_email = "your_email@example.com"
app_license = "MIT"

doctype_js = {
    "Sales Order": "public/js/sales_order.js"
}
